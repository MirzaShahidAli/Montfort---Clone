import{a as t}from"./visitedNews.BmN7K1ri.js";document.addEventListener("astro:page-load",()=>{const e=document.querySelector("main[data-news]");!e||!e?.dataset.news||t(e.dataset.news)});
